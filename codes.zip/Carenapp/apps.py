from django.apps import AppConfig


class CarenappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Carenapp'
